['keys'] = {
	label = 'Vehicle Key',
	weight = 0,
	stack = false,
	close = true,
	description = 'Vehicle Key'
},

['fakeplate'] = {
	label = 'Fake Plate',
	weight = 220,
	client = {
		export = 'renzu_garage.Fakeplate',
	},
},