Config						= {}
Config.InfiniteRepairs		= false -- Should one repairkit last forever?
Config.RepairTime			= 15 -- In seconds, how long should a repair take?
Config.IgnoreAbort			= true -- Remove repairkit from inventory even if user aborts repairs?
Config.AllowMecano			= true -- Allow mechanics to use this repairkit?

Config.Locale = 'en'
