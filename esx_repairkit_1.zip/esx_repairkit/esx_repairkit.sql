INSERT INTO items (`name`,`label`,`limit`,`rare`,`can_remove`) VALUES
('repairkit', 'Repairkit', 3, 0, 1);