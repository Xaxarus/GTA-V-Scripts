# esx_repairkit [![Release](https://img.shields.io/github/release/condolent/esx_repairkit.svg)](https://github.com/condolent/esx_repairkit/releases/latest)
Simple repairkit script for FiveM ESX servers

### Requirements
* es_extended

### Installation
Download the [latest release](https://github.com/condolent/esx_repairkit/releases/latest) and rename the folder to esx_repairkit.

Drag the folder into your `<server-data>/resources/[esx]` folder and add this to your server.cfg
```
start esx_repairkit
```