# Pacific Standard Bank Heist Script by utku

Made by **utku#9999**

You can edit this freely. If you want to share an improved or edited version of this script, just please ask for my permission and credit me.

Altough I'm not sure, changing the folder name may break the script. Just don't change it.

[My Discord](https://discord.gg/yqHmvcr)

I share my ideas and announce upcoming scripts here, join if you are interested. I also try to help people as long as I have time, but you are encouraged to ask for help in FiveM forum.

[My Patreon](https://www.patreon.com/utkforeva)

This will be the last script I'm sharing to public, all of my next projects will be Patreon only.

## My Other Resources

- [Data Crack Mini Hacking Game](https://forum.cfx.re/t/standalone-datacrack-hacking-mini-game/1066972) --**FINISHED**--

- [Fleeca Bank Heists (will work for every bank and you can easily add new banks)](https://www.youtube.com/watch?v=92kEXiBzrPQ) --**FINISHED**--

- [Blaine County Savings Bank Heist (this one will be special like Pacific Heist too)](https://streamable.com/olr9e) --**SOON**--

- [Credit System (something like bitcoin or whatever you name it, basically a new currency with it's own markets, vehicle shops... Also vehicle plate change, phone number change and more.)](https://www.patreon.com/posts/credit-system-34192895) --**FINISHED**--

- Gangs System (very optimized and you can easily add more gangs and edit them, still very early phase but will be something like gang turfs and managing npc gang members, deploying them...) --**SOON**--

- [Discord ID Lookup in-game](https://cdn.discordapp.com/attachments/680097090986049548/683030895313420305/unknown.png) **FINISHED** 

- [Shift Log to Discord (Shift start and end date with total duration for whichever job you want)](https://www.patreon.com/posts/shift-log-to-34425325) --**FINISHED**--

- Advanced Smuggler's Job (Buying warehouse and smuggling goods) --**SOON**--

## Installation

- You will need "utk_ornateprops" for this script to work with gold and diamond looting, you can turn it off in "client.lua",

- First add items in your database, you can find the relevant sql file in here,

- After sql make sure you have these scripts installed and working fine:

[ESX](https://github.com/ESX-Org/es_extended)

[mythic_notify](https://github.com/mythicrp/mythic_notify) IMPORTANT INFO: This file name must be "mythic_notify"

or

[pNotify](https://github.com/Nick78111/pNotify) IMPORTANT INFO: This file name must be "pNotify"

[progressBars](https://github.com/torpidity/progressBars/releases/tag/1.0) IMPORTANT INFO: This file name must be "progressBars"

- Then just copy "utk_ornateheist" and "utk_ornateprops" to you resources file and start them from "server.cfg", make sure to start "utk_ornateprops" before the "utk_ornateheist" just in case.

- If you want to use pNotify copy clientpNotify.lua and change its name to client.lua (THIS IS VERY IMPORTANT!)

## Configuration

- There are a lot of comment lines inside the code for you to understand better, you can disable extraprops(gold, diamond) in "client.lua",

- In "server.lua" also comment lines for you to edit easily.
