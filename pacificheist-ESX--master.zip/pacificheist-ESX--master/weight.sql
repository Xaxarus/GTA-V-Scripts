INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES -- you will need to check database structure before running this, my version of esx and yours may not be the same
    ('id_card', 'ID Card', 1, 0, 1),
    ('thermal_charge', 'Thermal Charge', 1, 0, 1),
    ('laptop_h', 'Hacker Laptop', 1, 0, 1),
    ('lockpick', 'Lockpick', 1, 0, 1), -- you may have this already so check it out
    ('gold_bar', 'Gold Bar', 2, 0, 1), -- you may need to edit limit and stuff
    ('dia_box', 'Diamond Box', 2, 0, 1); -- you may need to edit limit and stuff
