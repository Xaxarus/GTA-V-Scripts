fx_version 'adamant'

game 'gta5'

client_script 'client.lua'

server_script 'server.lua'

files {
    "html/alarm.html",
    "html/alarm.ogg"
}

ui_page 'html/alarm.html'
