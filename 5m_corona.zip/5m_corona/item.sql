INSERT INTO `items` (name, label) VALUES
  ('anticorona','Corona Tretment')
;
