# esx_kr_illness
A simple skripts that makes you sick.

[INSTALLATION]

```
1. Put the script in your resource-map.
2. Write esx_kr_illness in your server.cfg.
3. Insert the item.sql into your database.
```
[PLEASE NOTE]
```
I ask you to not re-release this script or sell it.
```

