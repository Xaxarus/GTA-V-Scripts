# ESX_GiveID

Dependency: es_extended,
            esx_identity
            
Type "/giveid" to the player you're facing for a notification to appear in the lower right hand corner with the ID information.            


Credits: E1Gamer, Smallo, and little bit of Jaymo <br/>
Created for Paradox Gaming http://discord.paradoxgaming.co/
