resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

---------------------------------------------
-- http://discord.gg/5bskZZ7
---------------------------------------------

description 'st-cctv'

version '1.0.2'

client_scripts {
	'client.lua'
}
