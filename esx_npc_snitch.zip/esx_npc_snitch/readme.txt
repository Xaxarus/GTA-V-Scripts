Leporde#8953

Please don't take this and sell it or put it in a tier, also give credits.