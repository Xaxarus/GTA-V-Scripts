# nation_bennys
- FIVEM Mechanic Menu
- Edit line 5 script.js to Change Translation:
- Example: script.js:5 'en' to 'jp'
![alt text](https://i.imgur.com/wpr9IVh.png)
- Info: a lot of people are requesting this, so here is my version, this is actually made few months ago now i am sharing it.

- All Events needed are converted from VRPEX to ESX (TESTED v1 final)

- if you found a bug i will fixed it when i have a time:

- Added Society Money Option at config: Mechanic can earn money from the script to their society money.
- Money being used is either bank or

- Dependencies: Esx Datastore, Mysql, esx_society, progressbar
