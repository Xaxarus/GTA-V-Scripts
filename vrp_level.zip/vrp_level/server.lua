MySQL = module("vrp_mysql", "MySQL")
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","vrp_level")

local toggle = false 
local rainbowveh = false
local speed = 0.25

RegisterServerEvent('startrainbow')
AddEventHandler('startrainbow', function()
	local function RGBRainbow( frequency )
		local result = {}
		local curtime = GetGameTimer() / 1000

		result.r = math.floor( math.sin( curtime * frequency + 0 ) * 127 + 128 )
		result.g = math.floor( math.sin( curtime * frequency + 2 ) * 127 + 128 )
		result.b = math.floor( math.sin( curtime * frequency + 4 ) * 127 + 128 )
	
		return result
	end
	local rainbow = RGBRainbow( speed )
    	Citizen.Wait(0)
    	if rainbowveh then
    		if IsPedInAnyVehicle(PlayerPedId(), true) then
    			veh = GetVehiclePedIsUsing(PlayerPedId())
    			SetVehicleCustomPrimaryColour(veh, rainbow.r, rainbow.g, rainbow.b)
    			SetVehicleCustomSecondaryColour(veh, rainbow.r, rainbow.g, rainbow.b)
    		else
    			rainbowveh = false
    			toggle = false
    		end
    	end

end)
 

local function vip_menu(player, choice)

	vRP.buildMenu({"Cont Premium", {player = player}, function(menu)
		
		menu.name = "Cont Premium"
		menu.css={top="75px",header_color="rgba(0,255,213,0.75)"}
		menu.onclose = function(player) vRP.openMainMenu({player}) end -- nest menu
		local user_id = vRP.getUserId({player})
		local player = vRP.getUserSource({user_id})
		

			menu["Vehicle Rainbow"] = {function(player,choice)
				local user_id = vRP.getUserId({player})
			--	if IsPedInAnyVehicle(user_id, true) then
					if user_id ~= nil then
						TriggerClientEvent("vip_rainbow", player)
						rainbowveh = true
					end
			--	else
			--		TriggerClientEvent("mesajmasina")
			--	end
			end,"Activeaza RAINBOW pe vehicul."}
			
			menu["Salt cu parasuta"] = {function(player,choice)
				local user_id = vRP.getUserId({player})
					if user_id ~= nil then
						TriggerClientEvent("Skyfall:DoFall", player)
					end
			end,"Salt cu parasuta."}


			menu["Stop Vehicle Rainbow"] = {function(player,choice)
				local user_id = vRP.getUserId({player})
			--	if IsPedInAnyVehicle(user_id, true) then
					if user_id ~= nil then
					
						TriggerClientEvent("vip_rainbowstop", player)
					end
		--		else
			--		TriggerClientEvent("mesajmasina")
			--	end
			end,"Opreste RAINBOW pe vehicul."}
			
	

		vRP.openMenu({player,menu})

	end})
end
vRP.registerMenuBuilder({"main", function(add, data)
	local user_id = vRP.getUserId({data.player})
	if user_id ~= nil then
		local choices = {}
		if vRP.hasPermission({user_id, "contpremium.menu"}) then
			choices["Cont Premium"] = {vip_menu, "Cont Premium"}
		end
		add(choices)
	end
end})

