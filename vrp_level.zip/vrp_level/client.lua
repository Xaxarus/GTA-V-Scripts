local toggle = false 
local rainbowveh = false
local speed = 0.25


RegisterNetEvent("vip_rainbow")
AddEventHandler("vip_rainbow", function ()
	rainbowveh = true
	TriggerEvent("chatMessage", "", {255,255,255}, "Vehicle Rainbow: ^2^*Enabled")
	speed = 10
end)

RegisterNetEvent("vip_rainbowstop")
AddEventHandler("vip_rainbowstop", function ()
	rainbowveh = false
	TriggerEvent("chatMessage", "", {255,255,255}, "Vehicle Rainbow: ^8^*Disabled")
	speed = 0
end)

RegisterNetEvent("mesajmasina")
AddEventHandler("mesajmasina", function ()
	rainbowveh = false
	TriggerEvent("chatMessage", "", {255,255,255}, "Vehicle Rainbow: ^8^*NU ESTI INTR-O MASINA")
	speed = 0
end)



local isSkyfall = false

function DisplayHelpText(message)
	SetTextComponentFormat("STRING")
	AddTextComponentString(message)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

RegisterNetEvent("Skyfall:DoFall")
AddEventHandler('Skyfall:DoFall', function()
	if not isSkyfall then
		isSkyfall = true

		CreateThread(function()
			local playerPed = PlayerPedId()
			local playerPos = GetEntityCoords(playerPed)

			GiveWeaponToPed(playerPed, GetHashKey('gadget_parachute'), 1, true, true)

			DoScreenFadeOut(3000)

			while not IsScreenFadedOut() do
				Wait(0)
			end

			SetEntityCoords(playerPed, playerPos.x, playerPos.y, playerPos.z + 500.0)

			DoScreenFadeIn(2000)

			Wait(2000)

			DisplayHelpText('Skyfall ~b~activated')

			SetPlayerInvincible(playerPed, true)
			SetEntityProofs(playerPed, true, true, true, true, true, false, 0, false)

			while true do
				if isSkyfall then			
					if IsPedInParachuteFreeFall(playerPed) and not HasEntityCollidedWithAnything(playerPed) then
						ApplyForceToEntity(playerPed, true, 0.0, 200.0, 2.5, 0.0, 0.0, 0.0, false, true, false, false, false, true)
					else
						isSkyfall = false
					end
				else

					break
				end

				Wait(0)
			end

			RemoveWeaponFromPed(playerPed, GetHashKey('gadget_parachute'))

			Wait(3000)

			SetPlayerInvincible(playerPed, false)
			SetEntityProofs(playerPed, false, false, false, false, false, false, 0, false)
		end)
	end
end)



Citizen.CreateThread(function()
	local function RGBRainbow( frequency )
		local result = {}
		local curtime = GetGameTimer() / 1000

		result.r = math.floor( math.sin( curtime * frequency + 0 ) * 127 + 128 )
		result.g = math.floor( math.sin( curtime * frequency + 2 ) * 127 + 128 )
		result.b = math.floor( math.sin( curtime * frequency + 4 ) * 127 + 128 )
	
		return result
	end
    while true do
    	local rainbow = RGBRainbow( speed )
    	Citizen.Wait(0)
    	if rainbowveh then
    		if IsPedInAnyVehicle(PlayerPedId(), true) then
    			veh = GetVehiclePedIsUsing(PlayerPedId())
    			SetVehicleCustomPrimaryColour(veh, rainbow.r, rainbow.g, rainbow.b)
    			SetVehicleCustomSecondaryColour(veh, rainbow.r, rainbow.g, rainbow.b)
    		else
    			rainbowveh = false
    			toggle = false
    		end
    	end
    end
end)