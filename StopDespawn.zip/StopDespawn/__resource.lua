server_scripts {
	'config.lua',
	'server.lua'
}
client_scripts {
	'config.lua',
	'client.lua'
}