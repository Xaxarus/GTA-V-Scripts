-- deprecated
--[[function getCharTattoos(source)
  TriggerEvent("es:getPlayerFromId", source, function(user)
    local results = MySQL.Sync.fetchAll("SELECT tattoos FROM characters WHERE charName = @charname", {['@charname'] = user.get("activeChar")})
    
    if (results[1]) then
      return json.decode(results[1].tattoos)
    end
  end)
end]]

AddEventHandler("bms:tattoo:getCharTattoos", function(source, cb)
  TriggerEvent("es:getPlayerFromId", source, function(user)
    MySQL.Async.fetchAll("SELECT tattoos FROM characters WHERE charName = @charname", {['@charname'] = user.get("activeChar")}, function(results)
      if (cb and results[1]) then
        cb(json.decode(results[1].tattoos))
      end
    end)
  end)
end)

RegisterServerEvent("bms:tattoo:activateTattooShop")
AddEventHandler("bms:tattoo:activateTattooShop", function()
  local src = source
  
  --local playerTats = getCharTattoos(src)
  TriggerEvent("bms:tattoo:getCharTattoos", src, function(playerTats)
    TriggerClientEvent("bms:tattoo:setAllCharTattoos", src, playerTats)
  end)
end)

RegisterServerEvent("bms:tattoos:getTattoosForCategory")
AddEventHandler("bms:tattoos:getTattoosForCategory", function(cat, gender)
  if (cat) then
    local tats = {}
    
    for _,v in pairs(tattooList) do
      if (v.category == cat and v.gender == gender) then
        table.insert(tats, v)
      end
    end
    
    TriggerClientEvent("bms:tattoos:setTattoosForCat", source, tats)
  end
end)

RegisterServerEvent("bms:tattoos:requestTattooData")
AddEventHandler("bms:tattoos:requestTattooData", function(name, gender)
  if (name) then
    for _,v in pairs(tattooList) do
      if (v.name == name and v.gender == gender) then
        TriggerClientEvent("bms:tattoos:setTattooData", source, v)
        break
      end
    end
  end
end)

RegisterServerEvent("bms:tattoos:saveCharTattoos")
AddEventHandler("bms:tattoos:saveCharTattoos", function(tats)
  if (tats) then
    local src = source
    local tatenc = json.encode(tats)
    
    TriggerEvent("es:getPlayerFromId", src, function(user)
      MySQL.Async.execute("UPDATE characters SET `tattoos`=@tatenc WHERE charName = @charname", {['@tatenc'] = tatenc, ['@charname'] = user.get("activeChar")})
    end)
  end
end)






