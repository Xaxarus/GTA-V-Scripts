fx_version 'bodacious'
game 'gta5'
author 'Thunder Shop - https://discord.gg/F3G8W2ruDN'

this_is_a_map 'yes'

            