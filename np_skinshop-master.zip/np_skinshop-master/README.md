## NP_SKINSHOP

This is a simple, but very inneficient way of displaying all the game clothes and props in a pretty(ish) way.
This is just the interface code, so you'll still need to implement it to your server.
Feel free to use it and/or post different versions. Though, please don't forget to link the repositorie as the source-code.

Ps. The interface HTML is horrendous, it's just huge, so handle it carrefully. Also the CSS is very bad, as this was one of my first projects. A interface rebuild is recommended.

Demonstration: https://streamable.com/ne6wn

[![print1](https://imgur.com/zUnh5Gj.png)](https://imgur.com/zUnh5Gj.png)
