
Weapons = {}

-- ADD WEAPON PERMMISION HERE
-- THIS IS ONLY BEING USE FOR WEAPON ARMORY FEATURE so EACH RANK CAN HAVE A WEAPON CATEGORY


--- POLICE JOB PERMMISION
--- POLICE JOB PERMMISION
--- POLICE JOB PERMMISION
Weapons['police'] = {
	['WEAPON_PISTOL'] = {	mingrade = 0},

	['WEAPON_COMBATPISTOL'] = {	mingrade = 2},

	['WEAPON_APPISTOL'] = {	mingrade = 5},

	['WEAPON_PISTOL50'] = {	mingrade = 7},

	['WEAPON_SNSPISTOL'] = {	mingrade = 6},

	['WEAPON_HEAVYPISTOL'] = {	mingrade = 8},

	['WEAPON_VINTAGEPISTOL'] = {	mingrade = 1},

	['WEAPON_MACHINEPISTOL'] = {	mingrade = 4},

	['WEAPON_REVOLVER'] = { mingrade = 8},
    ['WEAPON_MARKSMANPISTOL'] = { mingrade = 8},
    ['WEAPON_DOUBLEACTION'] = { mingrade = 7},

	['WEAPON_SMG'] = {	mingrade = 2},

	['WEAPON_ASSAULTSMG'] = {	mingrade = 6},

	['WEAPON_MICROSMG'] = {	mingrade = 4},

	['WEAPON_MINISMG'] = {	mingrade = 4},

	['WEAPON_COMBATPDW'] = {	mingrade = 3},

	['WEAPON_PUMPSHOTGUN'] = {	mingrade = 5},
	
	['WEAPON_PISTOL_MK2'] = {	mingrade = 7},
	['WEAPON_REVOLVER_MK2'] = {	mingrade = 9},
	['WEAPON_SNSPISTOL_MK2'] = {	mingrade = 9},
	['WEAPON_PUMPSHOTGUN_MK2'] = {	mingrade = 9},

	['WEAPON_SAWNOFFSHOTGUN'] = {	mingrade = 9},

	['WEAPON_ASSAULTSHOTGUN'] = {	mingrade = 9},

	['WEAPON_BULLPUPSHOTGUN'] = {	mingrade = 9},

	['WEAPON_HEAVYSHOTGUN'] = {	mingrade = 9},
	

	['WEAPON_DBSHOTGUN'] = { mingrade = 9},
    ['WEAPON_AUTOSHOTGUN'] = { mingrade = 9},
    ['WEAPON_MUSKET'] = { mingrade = 9},

	['WEAPON_ASSAULTRIFLE'] = {	mingrade = 7},
	['WEAPON_ASSAULTRIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_CARBINERIFLE'] = {	mingrade = 0},
	['WEAPON_CARBINERIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_ADVANCEDRIFLE'] = {	mingrade = 7},

	['WEAPON_SPECIALCARBINE'] = {	mingrade = 7},
	['WEAPON_SPECIALCARBINE_MK2'] = {	mingrade = 9},

	['WEAPON_BULLPUPRIFLE'] = {	mingrade = 6},
	['WEAPON_BULLPUPRIFLE_MK2'] = {	mingrade = 9},
	['WEAPON_COMBATMG_MK2'] = {	mingrade = 9},
	['WEAPON_HEAVYSNIPER_MK2'] = {	mingrade = 9},
	['WEAPON_MARKSMANRIFLE_MK2'] = {	mingrade = 9},


	['WEAPON_COMPACTRIFLE'] = {	mingrade = 7},

	['WEAPON_MG'] = {	mingrade = 9},

	['WEAPON_COMBATMG'] = {	mingrade = 9},

	['WEAPON_GUSENBERG'] = {	mingrade = 8},

	['WEAPON_SNIPERRIFLE'] = {	mingrade = 9},

	['WEAPON_HEAVYSNIPER'] = {	mingrade = 9},

	['WEAPON_MARKSMANRIFLE'] = {	mingrade = 9},

	['WEAPON_MINIGUN'] = { mingrade = 9},
    ['WEAPON_RAILGUN'] = { mingrade = 9},
    ['WEAPON_STUNGUN'] = { mingrade = 9},
    ['WEAPON_RPG'] = { mingrade = 9},
    ['WEAPON_HOMINGLAUNCHER'] = { mingrade = 9},
    ['WEAPON_GRENADELAUNCHER'] = { mingrade = 9},
    ['WEAPON_COMPACTLAUNCHER'] = { mingrade = 9},
    ['WEAPON_FLAREGUN'] = { mingrade = 9},
    ['WEAPON_FIREEXTINGUISHER'] = { mingrade = 3},
    ['WEAPON_PETROLCAN'] = { mingrade = 9},
    ['WEAPON_FIREWORK'] = { mingrade = 9},
    ['WEAPON_FLASHLIGHT'] = { mingrade = 0},
    ['GADGET_PARACHUTE'] = { mingrade = 0},
    ['WEAPON_KNUCKLE'] = { mingrade = 9},
    ['WEAPON_HATCHET'] = { mingrade = 9},
    ['WEAPON_MACHETE'] = { mingrade = 9},
    ['WEAPON_SWITCHBLADE'] = { mingrade = 9},
    ['WEAPON_BOTTLE'] = { mingrade = 9},
    ['WEAPON_DAGGER'] = { mingrade = 9},
    ['WEAPON_POOLCUE'] = { mingrade = 9},
    ['WEAPON_WRENCH'] = { mingrade = 9},
    ['WEAPON_BATTLEAXE'] = { mingrade = 9},
    ['WEAPON_KNIFE'] = { mingrade = 0},
    ['WEAPON_NIGHTSTICK'] = { mingrade = 0},
    ['WEAPON_HAMMER'] = { mingrade = 9},
    ['WEAPON_BAT'] = { mingrade = 9},
    ['WEAPON_GOLFCLUB'] = { mingrade = 9},
    ['WEAPON_CROWBAR'] = { mingrade = 9},

	['WEAPON_GRENADE'] = { mingrade = 9},
    ['WEAPON_SMOKEGRENADE'] = { mingrade = 9},
    ['WEAPON_STICKYBOMB'] = { mingrade = 9},
    ['WEAPON_PIPEBOMB'] = { mingrade = 9},
    ['WEAPON_BZGAS'] = { mingrade = 9},
    ['WEAPON_FLASHBANG'] = { mingrade = 9},
    ['WEAPON_MOLOTOV'] = { mingrade = 9},
    ['WEAPON_PROXMINE'] = { mingrade = 9},
    ['WEAPON_SNOWBALL'] = { mingrade = 9},
    ['WEAPON_BALL'] = { mingrade = 9},
    ['WEAPON_FLARE'] = { mingrade = 9},
}






--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION



--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION


--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION
--- lostmc JOB PERMMISION
Weapons['lostmc'] = {
	['WEAPON_PISTOL'] = {	mingrade = 0},

	['WEAPON_COMBATPISTOL'] = {	mingrade = 1},

	['WEAPON_APPISTOL'] = {	mingrade = 1},

	['WEAPON_PISTOL50'] = {	mingrade = 1},

	['WEAPON_SNSPISTOL'] = {	mingrade = 1},

	['WEAPON_HEAVYPISTOL'] = {	mingrade = 1},

	['WEAPON_VINTAGEPISTOL'] = {	mingrade = 1},

	['WEAPON_MACHINEPISTOL'] = {	mingrade = 4},

	['WEAPON_REVOLVER'] = { mingrade = 1},
    ['WEAPON_MARKSMANPISTOL'] = { mingrade = 1},
    ['WEAPON_DOUBLEACTION'] = { mingrade = 1},

	['WEAPON_SMG'] = {	mingrade = 2},

	['WEAPON_ASSAULTSMG'] = {	mingrade = 1},

	['WEAPON_MICROSMG'] = {	mingrade = 4},

	['WEAPON_MINISMG'] = {	mingrade = 4},

	['WEAPON_COMBATPDW'] = {	mingrade = 3},

	['WEAPON_PUMPSHOTGUN'] = {	mingrade = 5},
	
	['WEAPON_PISTOL_MK2'] = {	mingrade = 7},
	['WEAPON_REVOLVER_MK2'] = {	mingrade = 9},
	['WEAPON_SNSPISTOL_MK2'] = {	mingrade = 9},
	['WEAPON_PUMPSHOTGUN_MK2'] = {	mingrade = 9},

	['WEAPON_SAWNOFFSHOTGUN'] = {	mingrade = 9},

	['WEAPON_ASSAULTSHOTGUN'] = {	mingrade = 9},

	['WEAPON_BULLPUPSHOTGUN'] = {	mingrade = 9},

	['WEAPON_HEAVYSHOTGUN'] = {	mingrade = 9},
	

	['WEAPON_DBSHOTGUN'] = { mingrade = 9},
    ['WEAPON_AUTOSHOTGUN'] = { mingrade = 9},
    ['WEAPON_MUSKET'] = { mingrade = 9},

	['WEAPON_ASSAULTRIFLE'] = {	mingrade = 7},
	['WEAPON_ASSAULTRIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_CARBINERIFLE'] = {	mingrade = 0},
	['WEAPON_CARBINERIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_ADVANCEDRIFLE'] = {	mingrade = 7},

	['WEAPON_SPECIALCARBINE'] = {	mingrade = 7},
	['WEAPON_SPECIALCARBINE_MK2'] = {	mingrade = 9},

	['WEAPON_BULLPUPRIFLE'] = {	mingrade = 6},
	['WEAPON_BULLPUPRIFLE_MK2'] = {	mingrade = 9},
	['WEAPON_COMBATMG_MK2'] = {	mingrade = 9},
	['WEAPON_HEAVYSNIPER_MK2'] = {	mingrade = 9},
	['WEAPON_MARKSMANRIFLE_MK2'] = {	mingrade = 9},


	['WEAPON_COMPACTRIFLE'] = {	mingrade = 7},

	['WEAPON_MG'] = {	mingrade = 9},

	['WEAPON_COMBATMG'] = {	mingrade = 9},

	['WEAPON_GUSENBERG'] = {	mingrade = 8},

	['WEAPON_SNIPERRIFLE'] = {	mingrade = 9},

	['WEAPON_HEAVYSNIPER'] = {	mingrade = 9},

	['WEAPON_MARKSMANRIFLE'] = {	mingrade = 9},

	['WEAPON_MINIGUN'] = { mingrade = 9},
    ['WEAPON_RAILGUN'] = { mingrade = 9},
    ['WEAPON_STUNGUN'] = { mingrade = 9},
    ['WEAPON_RPG'] = { mingrade = 9},
    ['WEAPON_HOMINGLAUNCHER'] = { mingrade = 9},
    ['WEAPON_GRENADELAUNCHER'] = { mingrade = 9},
    ['WEAPON_COMPACTLAUNCHER'] = { mingrade = 9},
    ['WEAPON_FLAREGUN'] = { mingrade = 9},
    ['WEAPON_FIREEXTINGUISHER'] = { mingrade = 3},
    ['WEAPON_PETROLCAN'] = { mingrade = 9},
    ['WEAPON_FIREWORK'] = { mingrade = 9},
    ['WEAPON_FLASHLIGHT'] = { mingrade = 0},
    ['GADGET_PARACHUTE'] = { mingrade = 0},
    ['WEAPON_KNUCKLE'] = { mingrade = 9},
    ['WEAPON_HATCHET'] = { mingrade = 9},
    ['WEAPON_MACHETE'] = { mingrade = 9},
    ['WEAPON_SWITCHBLADE'] = { mingrade = 9},
    ['WEAPON_BOTTLE'] = { mingrade = 9},
    ['WEAPON_DAGGER'] = { mingrade = 9},
    ['WEAPON_POOLCUE'] = { mingrade = 9},
    ['WEAPON_WRENCH'] = { mingrade = 9},
    ['WEAPON_BATTLEAXE'] = { mingrade = 9},
    ['WEAPON_KNIFE'] = { mingrade = 0},
    ['WEAPON_NIGHTSTICK'] = { mingrade = 0},
    ['WEAPON_HAMMER'] = { mingrade = 9},
    ['WEAPON_BAT'] = { mingrade = 9},
    ['WEAPON_GOLFCLUB'] = { mingrade = 9},
    ['WEAPON_CROWBAR'] = { mingrade = 9},

	['WEAPON_GRENADE'] = { mingrade = 9},
    ['WEAPON_SMOKEGRENADE'] = { mingrade = 9},
    ['WEAPON_STICKYBOMB'] = { mingrade = 9},
    ['WEAPON_PIPEBOMB'] = { mingrade = 9},
    ['WEAPON_BZGAS'] = { mingrade = 9},
    ['WEAPON_FLASHBANG'] = { mingrade = 9},
    ['WEAPON_MOLOTOV'] = { mingrade = 9},
    ['WEAPON_PROXMINE'] = { mingrade = 9},
    ['WEAPON_SNOWBALL'] = { mingrade = 9},
    ['WEAPON_BALL'] = { mingrade = 9},
    ['WEAPON_FLARE'] = { mingrade = 9},
}

--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION

--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION

--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION
--- mechanic JOB PERMMISION
Weapons['mechanic'] = {
	['WEAPON_PISTOL'] = {	mingrade = 0},

	['WEAPON_COMBATPISTOL'] = {	mingrade = 2},

	['WEAPON_APPISTOL'] = {	mingrade = 5},

	['WEAPON_PISTOL50'] = {	mingrade = 7},

	['WEAPON_SNSPISTOL'] = {	mingrade = 6},

	['WEAPON_HEAVYPISTOL'] = {	mingrade = 8},

	['WEAPON_VINTAGEPISTOL'] = {	mingrade = 1},

	['WEAPON_MACHINEPISTOL'] = {	mingrade = 4},

	['WEAPON_REVOLVER'] = { mingrade = 8},
    ['WEAPON_MARKSMANPISTOL'] = { mingrade = 8},
    ['WEAPON_DOUBLEACTION'] = { mingrade = 7},

	['WEAPON_SMG'] = {	mingrade = 2},

	['WEAPON_ASSAULTSMG'] = {	mingrade = 6},

	['WEAPON_MICROSMG'] = {	mingrade = 4},

	['WEAPON_MINISMG'] = {	mingrade = 4},

	['WEAPON_COMBATPDW'] = {	mingrade = 3},

	['WEAPON_PUMPSHOTGUN'] = {	mingrade = 5},
	
	['WEAPON_PISTOL_MK2'] = {	mingrade = 7},
	['WEAPON_REVOLVER_MK2'] = {	mingrade = 9},
	['WEAPON_SNSPISTOL_MK2'] = {	mingrade = 9},
	['WEAPON_PUMPSHOTGUN_MK2'] = {	mingrade = 9},

	['WEAPON_SAWNOFFSHOTGUN'] = {	mingrade = 9},

	['WEAPON_ASSAULTSHOTGUN'] = {	mingrade = 9},

	['WEAPON_BULLPUPSHOTGUN'] = {	mingrade = 9},

	['WEAPON_HEAVYSHOTGUN'] = {	mingrade = 9},
	

	['WEAPON_DBSHOTGUN'] = { mingrade = 9},
    ['WEAPON_AUTOSHOTGUN'] = { mingrade = 9},
    ['WEAPON_MUSKET'] = { mingrade = 9},

	['WEAPON_ASSAULTRIFLE'] = {	mingrade = 7},
	['WEAPON_ASSAULTRIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_CARBINERIFLE'] = {	mingrade = 0},
		['WEAPON_CARBINERIFLE_MK2'] = {	mingrade = 9},

	['WEAPON_ADVANCEDRIFLE'] = {	mingrade = 7},

	['WEAPON_SPECIALCARBINE'] = {	mingrade = 7},
	['WEAPON_SPECIALCARBINE_MK2'] = {	mingrade = 9},

	['WEAPON_BULLPUPRIFLE'] = {	mingrade = 6},
	['WEAPON_BULLPUPRIFLE_MK2'] = {	mingrade = 9},
	['WEAPON_COMBATMG_MK2'] = {	mingrade = 9},
	['WEAPON_HEAVYSNIPER_MK2'] = {	mingrade = 9},
	['WEAPON_MARKSMANRIFLE_MK2'] = {	mingrade = 9},


	['WEAPON_COMPACTRIFLE'] = {	mingrade = 7},

	['WEAPON_MG'] = {	mingrade = 9},

	['WEAPON_COMBATMG'] = {	mingrade = 9},

	['WEAPON_GUSENBERG'] = {	mingrade = 8},

	['WEAPON_SNIPERRIFLE'] = {	mingrade = 9},

	['WEAPON_HEAVYSNIPER'] = {	mingrade = 9},

	['WEAPON_MARKSMANRIFLE'] = {	mingrade = 9},

	['WEAPON_MINIGUN'] = { mingrade = 9},
    ['WEAPON_RAILGUN'] = { mingrade = 9},
    ['WEAPON_STUNGUN'] = { mingrade = 9},
    ['WEAPON_RPG'] = { mingrade = 9},
    ['WEAPON_HOMINGLAUNCHER'] = { mingrade = 9},
    ['WEAPON_GRENADELAUNCHER'] = { mingrade = 9},
    ['WEAPON_COMPACTLAUNCHER'] = { mingrade = 9},
    ['WEAPON_FLAREGUN'] = { mingrade = 9},
    ['WEAPON_FIREEXTINGUISHER'] = { mingrade = 3},
    ['WEAPON_PETROLCAN'] = { mingrade = 9},
    ['WEAPON_FIREWORK'] = { mingrade = 9},
    ['WEAPON_FLASHLIGHT'] = { mingrade = 0},
    ['GADGET_PARACHUTE'] = { mingrade = 0},
    ['WEAPON_KNUCKLE'] = { mingrade = 9},
    ['WEAPON_HATCHET'] = { mingrade = 9},
    ['WEAPON_MACHETE'] = { mingrade = 9},
    ['WEAPON_SWITCHBLADE'] = { mingrade = 9},
    ['WEAPON_BOTTLE'] = { mingrade = 9},
    ['WEAPON_DAGGER'] = { mingrade = 9},
    ['WEAPON_POOLCUE'] = { mingrade = 9},
    ['WEAPON_WRENCH'] = { mingrade = 9},
    ['WEAPON_BATTLEAXE'] = { mingrade = 9},
    ['WEAPON_KNIFE'] = { mingrade = 0},
    ['WEAPON_NIGHTSTICK'] = { mingrade = 0},
    ['WEAPON_HAMMER'] = { mingrade = 9},
    ['WEAPON_BAT'] = { mingrade = 9},
    ['WEAPON_GOLFCLUB'] = { mingrade = 9},
    ['WEAPON_CROWBAR'] = { mingrade = 9},

	['WEAPON_GRENADE'] = { mingrade = 9},
    ['WEAPON_SMOKEGRENADE'] = { mingrade = 9},
    ['WEAPON_STICKYBOMB'] = { mingrade = 9},
    ['WEAPON_PIPEBOMB'] = { mingrade = 9},
    ['WEAPON_BZGAS'] = { mingrade = 9},
    ['WEAPON_FLASHBANG'] = { mingrade = 9},
    ['WEAPON_MOLOTOV'] = { mingrade = 9},
    ['WEAPON_PROXMINE'] = { mingrade = 9},
    ['WEAPON_SNOWBALL'] = { mingrade = 9},
    ['WEAPON_BALL'] = { mingrade = 9},
    ['WEAPON_FLARE'] = { mingrade = 9},
}