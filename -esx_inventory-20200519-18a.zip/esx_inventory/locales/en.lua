Locales ['en'] = {
  ['voice']   = '',
  ['normal']  = 'Нормално',
  ['shout']   = 'Викане',
  ['whisper'] = 'Шептене',
}
