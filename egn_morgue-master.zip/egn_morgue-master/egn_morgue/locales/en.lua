Locales['en'] = {
	['blip_name']          = 'Graveyard',
	['morgue']              = ' Morgue',
	['escape_attempt']     = ' You are not allowed to escape the Graveyard (LAST WARNING)!',
	['remaining_msg']      = ' Remains ~b~%s~s~ seconds until you are born',
	['morgued_msg']         = ' %s has passed away %s day/s ago. Family and Friends have been informed. RIP from LAFD!',
	['unmorgued']           = ' %s has been born!'
}