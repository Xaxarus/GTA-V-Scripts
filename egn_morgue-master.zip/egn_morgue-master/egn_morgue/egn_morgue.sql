CREATE TABLE morgue (
	identifier VARCHAR(100) NOT NULL,
	morgue_time int(10) NOT NULL,
	PRIMARY KEY (identifier)
);