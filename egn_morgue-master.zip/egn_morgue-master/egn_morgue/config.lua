Config = {}
Config.GraveyardBlip = {x = -1762.744, y = -262.012, z = 48.288}
Config.GraveyardLocation = {x = -1762.744, y = -262.012, z = 47.288}
Config.BornLocation = {x = 298.1268, y = -584.515, z = 43.26084}
Config.Locale = 'en'