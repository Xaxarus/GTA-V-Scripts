# egn_morgue
Send a player to the graveyard upon death.
