Config              = {}
Config.UseKPH		= false -- otherwise MPH
Config.DrawDistance	= 50 -- game units

Config.AlertCops	= false -- switch between sending 'intruder alert' to police
Config.UseGCPhone	= false -- switch between esx notif and gcphone for police alerts

Config.TicketCost	= 100 -- cash
Config.TicketTime	= 300 -- seconds

Config.WireCost		= 5 -- parts required to make bomb

Config.Zones = {
	
	CollectZones = {
		
		RecCenter = {
		
			Entrance = vector3(2340.87, 3128.60, 48.21),
		
			Yard = vector3(2351.30, 3053.58, 48.13)
		
		},
		
		SandyAirField = {
		
			Entrance = vector3(1759.38, 3298.74, 41.95),
			
			Yard = vector3(1754.16, 3322.97, 41.21)
			
		},
		
		MuriettaOilField = {
		
			Entrance = vector3(1569.64, -2129.88, 78.33),
			
			Yard = vector3(1507.80, -2129.14, 76.25)
			
		},
		
		HayesAuto = {
		
			Entrance = vector3(495.72, -1340.43, 29.31),
			
			Yard = vector3(456.52, -1316.19, 29.28)
			
		},
	
	},
	
	ProcessZones = {
			
		vector3(1272.81, -1711.55, 54.77),
		
		vector3(909.82, -3222.39, -98.27),
		
		vector3(1987.81, 3789.15, 32.18)
		
	},
	
	TeleInZones = {

		vector3(-3185.15, 1374.58, 19.47)
		
	},
	
	TeleOutZones = {

		vector3(902.61, -3182.32, -97.06)
		
	},
	
}