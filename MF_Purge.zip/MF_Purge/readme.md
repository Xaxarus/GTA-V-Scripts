-- ModFreakz
-- For support, previews and showcases, head to https://discord.gg/ukgQa5K

Requirements
- ESX
- progressBars
- InteractSound
- vSync

Installation
- Extract to resources folder
- Start in server.cfg
- If sql file provided, import it.
- Check the config for options you might want to change.
- Make sure requirements are installed and started in server.cfg (if not provided, please ask via discord).
- Make sure you're added to webhook. If you have no idea what that is, head to the link above and create a ticket.

Usage

/purge
- Admin command
At 6 PM, following this announcement, the purge event will begin.