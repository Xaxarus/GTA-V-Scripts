# Maori_Inventory
 
Custom Version of esx_inventoryhud done for MaoriRP

[Video] - (https://streamable.com/dwgaa)

Features:
-Glovebox
-Trunk
-Weight System
-Stealing
-Shops

Credits:

-Ty to Scrubz#0001 for helping me out in this project
-Ty to the Original esx_inventoryhud resource made by Trsak
