Locales["pt"] = {
    ["glovebox_closed"] = "Este Porta Luvas está Trancado.",
    ["no_veh_nearby"] = "Sem Veículos Próximos.",
    ["glovebox_in_use"] = "Porta Luvas em Uso.",
    ["glovebox_full"] = "Porta Luvas Cheio.",
    ["invalid_quantity"] = "Quantidade Inválida",
    ["cant_carry_more"] = "Não Podes Carregar Mais.",
    ["nacho_veh"] = "Este Veículo não é teu.",
    ["invalid_amount"] = "Quantidade Inválida",
    ["insufficient_space"] = "Espaço Insuficiente",
    ["glovebox_info"] = "<h3>Vehicle glovebox</h3><br><strong>Matrícula:</strong> %s<br><strong>Capacidade:</strong> %s / %s",
    ["player_inv_no_space"] = "Não Tens Espaço no Inventário!"
  }