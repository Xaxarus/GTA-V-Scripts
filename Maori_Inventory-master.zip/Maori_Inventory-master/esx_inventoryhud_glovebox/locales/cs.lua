Locales['cs'] = {
    ['glovebox_closed'] = 'přihrádka tohoto vozidla je zavřený.',
    ['no_veh_nearby'] = 'není u tebe žádné vozidlo.',
    ['glovebox_in_use'] = 'tento kufr již někdo používá.',
    ['glovebox_full'] = 'tento kufr je plný.',
    ['invalid_quantity'] = 'špatné množství!',
    ['cant_carry_more'] = 'více toho neuneseš.',
    ['nacho_veh'] = 'toto není tvoje vozidlo.',
    ['invalid_amount'] = 'Špatné množství!',
    ['insufficient_space'] = 'nedostatek místa!',
    ['glovebox_info'] = '<h3>Přihrádka vozidla</h3><br><strong>SPZ:</strong> %s<br><strong>Kapacita:</strong> %s / %s',
    ['player_inv_no_space'] = 'Tolik toho mít v inventáři nemůžeš!'
}
