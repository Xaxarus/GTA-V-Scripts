Locales['pt'] = {
	['cash'] = 'Dinheiro',
	['black_money'] = 'Dinheiro Sujo',
	['player_nearby'] = 'Não há jogadores por perto!',
	['players_nearby'] = 'Não há jogadores por perto!',
	["player_info"] = "<strong>Nome:</strong> %s<br><strong>Peso:</strong> %s / %s KG.",
	["player_info_full"] = "<h4 style='color:red;'>Inventário Cheio</h4><br><strong>Nome:</strong> %s<br><strong>Peso:</strong> %s / %s KG.",
	["insufficient_space"] = "Inventário Cheio!"
}