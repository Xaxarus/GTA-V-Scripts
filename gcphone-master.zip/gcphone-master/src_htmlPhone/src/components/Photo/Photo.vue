<script>
import PhoneAPI from './../../PhoneAPI'
export default {
  created () {
    PhoneAPI.faketakePhoto()
  }
}
</script>
