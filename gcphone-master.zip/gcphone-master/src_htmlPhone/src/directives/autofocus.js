const directive = {
  inserted (el) {
    el.focus()
  }
}

export default directive
