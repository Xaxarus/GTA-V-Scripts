Locales ['fi'] = {
  ['buy_license'] = 'osta lisenssi?',
  ['yes'] = '%s',
  ['no'] = 'ei',
  ['weapon_bought'] = 'purchased for %s EUR',
  ['not_enough_black'] = 'ei tarpeeksi likaista rahaa',
  ['not_enough'] = 'sinulla ei ole tarpeeksi rahaa',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'kauppa',
  ['shop_menu_prompt'] = 'paina ~INPUT_CONTEXT~ avataksesi kauppa ikkuna.',
  ['shop_menu_item'] = '%s EUR',
  ['map_blip'] = 'asekauppa',
}
