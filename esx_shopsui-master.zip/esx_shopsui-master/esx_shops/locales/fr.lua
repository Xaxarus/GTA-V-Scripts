Locales['fr'] = {
  ['shop'] = 'magasin',
  ['shops'] = 'magasins',
  ['press_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au magasin.',
  ['shop_item'] = '$%s',
  ['bought'] = 'vous venez d\'acheter ~y~%sx~s~ ~b~%s~s~ pour ~r~$%s~s~',
  ['not_enough'] = 'vous n\'avez ~r~pas assez~s~ d\'argent: %s',
  ['player_cannot_hold'] = 'vous n\'avez ~r~pas~s~ assez ~y~de place~s~ dans votre inventaire!',
  ['shop_confirm'] = 'acheter %sx %s pour $%s?',
  ['no'] = 'non',
  ['yes'] = 'oui',
}
