Locales['pl'] = {
  ['shop'] = 'Sklep',
  ['shops'] = 'Sklep',
  ['press_menu'] = 'Naciśnij ~INPUT_CONTEXT~ aby przejrzeć ofertę ~y~sklepu~s~.',
  ['shop_item'] = '$%s',
  ['bought'] = 'właśnie zakupiłeś ~y~%s~s~ x ~b~%s~s~ za ~g~%s $~s~',
  ['not_enough'] = 'nie masz ~r~wystarczjąco~s~ pięniędzy, ~y~Brakuje Ci~s~ ~r~$%s~s~!',
  ['player_cannot_hold'] = '~r~Nie~s~ masz wystarczająco ~y~wolnego miejsca~s~ w swoim ekwipunku!',
  ['shop_confirm'] = 'chcesz kupić %sx %s za $%s?',
  ['no'] = 'nie',
  ['yes'] = 'tak',
}
