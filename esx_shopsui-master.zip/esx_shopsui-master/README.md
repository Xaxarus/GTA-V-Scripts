
# FiveM - Shops UI

**This script adds new UI to esx_shops and esx_weaponshop.**

![Image](https://i.imgur.com/ZuoC6So.png)

# Credits

Name | URL
--- | ---
*esx_shops* | `https://github.com/ESX-Org/esx_shops`
*esx_weaponshop* | `https://github.com/ESX-Org/esx_weaponshop`
*mythic_notify* | `https://github.com/mythicrp/mythic_notify`

