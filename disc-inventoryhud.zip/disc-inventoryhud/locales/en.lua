Locales['en'] = {
 -- Client side
    ['used'] = "Item Used",
    ['keyshop'] = "Press ~INPUT_CONTEXT~ to open Shop",
    ['keystash'] = "Press ~INPUT_CONTEXT~ to open Stash",
-- Server side
    ['drop'] = "Drop",
    ['glove'] = "Glove Box",
    ['player'] = "Player",
    ['shop'] = "Shop",
    ['stash'] = "Stash",
    ['trunk'] = "Trunk-",
    ['added'] = "Item Added",
} 
