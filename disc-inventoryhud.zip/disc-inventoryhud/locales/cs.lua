Locales['cs'] = {
 -- Client side
    ['used'] = "Předmět použit",
    ['keyshop'] = "Stiskni ~INPUT_CONTEXT~ pro otevreni obchodu",
    ['keystash'] = "Stiskni ~INPUT_CONTEXT~ pro otevreni uschovny",
-- Server side
    ['drop'] = "Zahodit",
    ['glove'] = "Přihrádka",
    ['player'] = "Hráč",
    ['shop'] = "Obchod",
    ['stash'] = "Úschovna",
    ['trunk'] = "Kufr-",
    ['added'] = "Předmět přidán",
} 
