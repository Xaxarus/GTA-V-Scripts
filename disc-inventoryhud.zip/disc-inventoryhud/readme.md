# DEPRECATED

This mod has been deprecated in favour of an entire redesign [here](https://github.com/DiscworldZA/disc-inventoryhud) NO SUPPORT WILL BE GIVEN FOR THIS RESOURCE, TBD If take down is needed. This resource is TOO resource intensive and WILL kill your server.

# Stream

I stream on [Twitch](https://www.twitch.tv/DiscworldZA). Come hang out and learn from me!

# Download

Download available on my [repo](https://github.com/DiscworldZA/gta-resources)

# Credit
Thank you greatly to [Alzar_tv](https://github.com/mythicrp) for providing me with your front-end for mythic_inventory

- ESX_InventoryHUD (Inspiration)
