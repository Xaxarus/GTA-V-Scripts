
INSERT INTO `items` (`name`, `label`) VALUES
  ('drone_flyer_1','Basic Drone 1'),
  ('drone_flyer_2','Basic Drone 2'),
  ('drone_flyer_3','Basic Drone 3'),
  ('drone_flyer_4','Advanced Drone 1'),
  ('drone_flyer_5','Advanced Drone 2'),
  ('drone_flyer_6','Advanced Drone 3'),
  ('drone_flyer_7','Police Drone');
