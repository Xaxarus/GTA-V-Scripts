# HideInTrunk
 Hide in Trunk Script for Fivem
 
 #Features at the moment:
 
 1. hide in Trunk or open Trunk
 2. Only on not locked cars
 3. Only when there is no one on the driver seat. To prevent jumping in npc cars while they are driving
