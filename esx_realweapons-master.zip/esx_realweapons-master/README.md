# esx_realweapons
This resource makes so all your wepaons become wearables.

### Todo
- Configure all the positions ... of all the weapons (feel free to help out)

## Download & Installation

### Using [fvm](https://github.com/qlaffont/fvm-installer)
```
fvm install --save --folder=esx esx-public/esx_realweapons
```

### Using Git
```
cd resources
git clone https://github.com/ESX-PUBLIC/esx_realweapons [esx]/esx_realweapons
```

### Manually
- Download https://github.com/ESX-PUBLIC/esx_realweapons/archive/master.zip
- Put it in the `[esx]` directory

## Installation
- Add this to your `server.cfg`:

```
start esx_realweapons
```

# Legal
### License
esx_realweapons - visable weapons

Copyright (C) 2017-2018 renaiku

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.
