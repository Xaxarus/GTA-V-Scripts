fx_version 'adamant'

game 'gta5'

description 'ESX Real Weapons'

version '0.2.0'

client_scripts {
	'config.lua',
	'main.lua'
}

dependency 'es_extended'
