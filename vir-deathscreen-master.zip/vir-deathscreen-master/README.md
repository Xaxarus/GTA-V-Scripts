## Manually
Download https://github.com/Mika-fivem/vir-deathscreen
Put it in the [ressources] directory
## Installation
Instal the resource
Add start vir-deathscreen in your server.cfg:
-- start vir-deathscreen
## FOR SUPPORT: https://discord.gg/nfJb4bF
## DONT CHANGE THE NAME!!!! THE SCRIPT WILL BE BROKE
Credits:
-- ^Mika#4672 -- JanKrb | Dev#6964