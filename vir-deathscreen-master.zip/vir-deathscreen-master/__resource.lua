resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

client_script "main.lua"

ui_page 'html/ui.html'

files {
	'html/ui.html',
	'html/death.js',
	'html/app.js',
	'html/app.css',
	'html/img/1.png',
	'html/font/OSL.ttf',
	'html/death.html',
	'html/death.js',
	'html/death.css',
	'html/font/OSL.ttf',
	'html/font/OpenSans-Light.ttf',
	'html/font/OpenSans-Regular.ttf',
	'html/font/OpenSans-Semibold.ttf',
	'html/font/OpenSans-ExtraBold.ttf',
	'html/font/OpenSans-Bold.ttf',

}