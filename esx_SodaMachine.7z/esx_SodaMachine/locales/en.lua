Locales['en'] = {
	['vending'] = 'Machine en cours de traitement... Patienter.',
	['machine'] = 'Soda Machine',
	['machines'] = 'Soda Machines',
	['press_context'] = 'Appuyez sur ~INPUT_CONTEXT~ pour acheter',
	['bought'] = 'Vous avez achetez ~y~1x~s~ ~b~canette~s~ pour ~r~$1~s~',
	['not_enough'] = 'Pas assez d\'argent, il manque ~r~$%s~s~!',
	['player_cannot_hold'] = 'Vous n\'avez ~r~pas~s~ assez de ~y~place~s~ dans votre inventaire!',
	['refreshment'] = 'Tu apprécies ce bon rafraichissement',
	['broken'] = 'Cette machine est Hors Service',
	['out_of_product'] = 'Cette machine n\'a plus ce produit',
	['other_problem'] = 'La machine s\'est bloquée et à gardé ton argent.',
}