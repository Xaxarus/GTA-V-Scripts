# DRUG SYSTEM FOR ESX

### About
This is a complete drug system for ESX. Unique in every way!

### Contact
Discord: https://discord.gg/QmHf6Jq

### Requirements
- mHacking  
- progressBar

### Installation
1) Drag & drop the folder into your `resources` server folder.
2) Configure the config file to your liking.
3) Make sure to import the items.sql file into your database from esx_newDrugs folder
4) Add `start progressBars` to your server config.
5) Add `start mhacking` to your server config.
6) Add `start esx_newDrugs` to your server config.

### Important
If you want support with police notify, then you must have esx_outlawalert on your server.

If you use inventoryhud, then you can also download item pictures from the download link below.

You can download my versions of esx_outlawalert, mhacking and progressBar and use it on your server:
https://github.com/Hamza8700/fivem_scripts

Keep in mind that some esx_outlawalert may be in Danish, however you can easily translate with use of google translate or just shoot me a pm on discord.


