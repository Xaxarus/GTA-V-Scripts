INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('coke10g', 'Cocaine (10G)', 50, 0, 1),
('coke1g', 'Cocaine (1G)', 50, 0, 1),
('cokebrick', 'Cocaine Brick (100G)', 20, 0, 1),
('cokeburn', 'White USB-C', 2, 0, 1),
('drugbags', 'Bags', 80, 0, 1),
('weedburn', 'Green USB-C', 2, 0, 1),
('hqscale', 'High Quality Scale', 1, 0, 1),
('joint2g', 'Joint (2G)', 50, 0, 1),
('meth10g', 'Meth (10G)', 50, 0, 1),
('meth1g', 'Meth (1G)', 50, 0, 1),
('methbrick', 'Meth Brick (100G)', 20, 0, 1),
('methburn', 'Blue USB-C', 2, 0, 1),
('rolpaper', 'Rolling Paper', 80, 0, 1),
('weed20g', 'Weed (20G)', 100, 0, 1),
('weed4g', 'Weed (4G)', 200, 0, 1),
('weedbrick', 'Weed Brick (200G)', 25, 0, 1);

