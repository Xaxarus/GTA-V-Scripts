INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('cocacola', 'Coca Cola', -1, 0, 1),
	('fanta', 'Fanta Exotic', -1, 0, 1),
	('sprite', 'Sprite', -1, 0, 1),
	('loka', 'Loka Crush', -1, 0, 1),
	
	('cheesebows', 'OLW Ostbågar', -1, 0, 1),
	('chips', 'OLW 3xLök Chips', -1, 0, 1),
	('marabou', 'Marabou Mjölkchoklad', -1, 0, 1),
	
	('pizza', 'Kebab Pizza', -1, 0, 1),
	('burger', 'Bacon Burgare', -1, 0, 1),
	('pastacarbonara', 'Pasta Carbonara', -1, 0, 1),
	('macka', 'Skinkmacka', -1, 0, 1),
	
	('cigarett', 'Cigarett', -1, 0, 1),
	('lighter', 'Tändare', -1, 0, 1),
	('lotteryticket', 'Trisslott', -1, 0, 1)
;
