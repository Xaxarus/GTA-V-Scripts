# 99kr-shops

[ Info ]

- This is a shop/store script for ESX, this is different from the normal esx_shops as it is more interactive. You walk around in the store to grab stuff from the shelfs to put into your basket on L, then go to the cashier and be prompted with the choice to pay with cash or with your credit card. See video for better explanation

[ Features ]

- Customizable config file.

[ Installation ]

1. Download
2. Put this resource into your resources
3. Run the SQL file
4. Put `start 99kr-shops` into your server.cfg

- And change what you want.

[ Requirements ]

- ESX
- esx_menu_default
- pNotify

[ Video ]

- https://streamable.com/e7z1l
