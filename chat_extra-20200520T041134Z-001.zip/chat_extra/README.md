# CHAT-Extras

Standalone script to add extras on your car for LATAMRP server.

/extra all [true|false] -> to add all/remove extras (0 to 30).

/extra [1 to N] [true|false] -> to add/remove a specific extra on your car.

Feel free to use it. Any question or update please let me know.

By Igna and ShinXD
