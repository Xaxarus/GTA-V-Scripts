Config.JobsInPhone = {
    ["police"] = {
        order = 1,
        name = 'police',
        label = "Police",
        duty = false,
    },
    ["ambulance"] = {
        order = 2,
        name = 'ambulance',
        label = "EMS",
        duty = false,
    },
    ["tabac"] = {
        order = 3,
        name = 'tabac',
        label = "Tabac",
        duty = false,
    },
    ["burgershot"] = {
        order = 4,
        name = 'burgershot',
        label = "Burgershot",
        duty = false,
    },
    ["noodle"] = {
        order = 5,
        name = 'noodle',
        label = "Noodle",
        duty = false,
    },
    ["unicorn"] = {
        order = 6,
        name = 'unicorn',
        label = "Unicorn",
        duty = false,
    },
    ["paradise"] = {
        order = 7,
        name = 'paradise',
        label = "Paradise Club",
        duty = false,
    },
    ["mechanic"] = {
        order = 8,
        name = 'mechanic',
        label = "Benny\'s",
        duty = false,
    },
    ["recycle"] = {
        order = 9,
        name = 'recycle',
        label = "Recyclage",
        duty = false,
    },
}