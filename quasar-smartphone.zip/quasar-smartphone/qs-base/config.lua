Config = {}

Config.getSharedObject = 'esx:getSharedObject'  -- Configure your framework here.
Config.playerLoaded = 'esx:playerLoaded'    -- Configure your framework here.

Config.IbanPrefix = "QS"

Config.NumberPrefix = "553" -- Prefix of the number
Config.NumberDigits =  6 -- Amount of digits after the prefix