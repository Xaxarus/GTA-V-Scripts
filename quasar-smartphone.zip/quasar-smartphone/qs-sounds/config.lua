Config = {}

-- How much ofter the player position is updated?
Config.RefreshTime = 100

-- How much close player has to be to the sound before starting updating position?
Config.DistanceBeforeUpdate = 40