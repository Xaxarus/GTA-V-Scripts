local L0_1, L1_1, L2_1
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "qs-sounds:client:stateSound"
  L5_2 = A0_2
  L6_2 = "position"
  L7_2 = {}
  L7_2.soundId = A1_2
  L7_2.position = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
Position = L0_1
L0_1 = exports
L1_1 = "Position"
L2_1 = Position
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "qs-sounds:client:stateSound"
  L5_2 = A0_2
  L6_2 = "distance"
  L7_2 = {}
  L7_2.soundId = A1_2
  L7_2.distance = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
Distance = L0_1
L0_1 = exports
L1_1 = "Distance"
L2_1 = Distance
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "qs-sounds:client:stateSound"
  L4_2 = A0_2
  L5_2 = "destroy"
  L6_2 = {}
  L6_2.soundId = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
Destroy = L0_1
L0_1 = exports
L1_1 = "Destroy"
L2_1 = Destroy
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "qs-sounds:client:stateSound"
  L4_2 = A0_2
  L5_2 = "pause"
  L6_2 = {}
  L6_2.soundId = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
Pause = L0_1
L0_1 = exports
L1_1 = "Pause"
L2_1 = Pause
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "qs-sounds:client:stateSound"
  L4_2 = A0_2
  L5_2 = "resume"
  L6_2 = {}
  L6_2.soundId = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
Resume = L0_1
L0_1 = exports
L1_1 = "Resume"
L2_1 = Resume
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "qs-sounds:client:stateSound"
  L5_2 = A0_2
  L6_2 = "volume"
  L7_2 = {}
  L7_2.soundId = A1_2
  L7_2.volume = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
setVolume = L0_1
L0_1 = exports
L1_1 = "setVolume"
L2_1 = setVolume
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "qs-sounds:client:stateSound"
  L5_2 = A0_2
  L6_2 = "timestamp"
  L7_2 = {}
  L7_2.soundId = A1_2
  L7_2.time = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
setTimeStamp = L0_1
L0_1 = exports
L1_1 = "setTimeStamp"
L2_1 = setTimeStamp
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "qs-sounds:client:stateSound"
  L4_2 = source
  L5_2 = "destroyOnFinish"
  L6_2 = {}
  L6_2.soundId = A0_2
  L6_2.value = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
destroyOnFinish = L0_1
L0_1 = exports
L1_1 = "destroyOnFinish"
L2_1 = destroyOnFinish
L0_1(L1_1, L2_1)
