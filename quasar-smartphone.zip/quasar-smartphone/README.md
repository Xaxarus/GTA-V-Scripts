have fun with this shit, got leaked mf by bingymafia

you can find installation guides on his documentation, https://docs.quasar-store.com/quasar-smartphone/esx/instalation-guide