Config.Framework = 'ESX' -- Set ESX or QBCore.

-- If you are using ESX.

Config.getSharedObject = 'esx:getSharedObject'  -- Configure your framework here.