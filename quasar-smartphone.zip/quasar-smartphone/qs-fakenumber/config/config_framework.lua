
Config.Framework = 'ESX' -- Set ESX or QBCore.

-- If you are using QBCore.

Config.QBCoreGetCoreObject = 'qb-core'

-- If you are using ESX.

Config.getSharedObject = 'esx:getSharedObject'  -- Configure your framework here.