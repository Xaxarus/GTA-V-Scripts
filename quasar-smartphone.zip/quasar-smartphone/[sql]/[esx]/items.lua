["classic_phone"] = {
    ["name"] = "classic_phone",
    ["label"] = "Classic Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "classic_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["black_phone"] = {
    ["name"] = "black_phone",
    ["label"] = "Black Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "black_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["blue_phone"] = {
    ["name"] = "blue_phone",
    ["label"] = "Blue Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "blue_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["gold_phone"] = {
    ["name"] = "gold_phone",
    ["label"] = "Gold Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "gold_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["purple_phone"] = {
    ["name"] = "purple_phone",
    ["label"] = "Purple Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "purple_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["red_phone"] = {
    ["name"] = "red_phone",
    ["label"] = "Red Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "red_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["green_phone"] = {
    ["name"] = "green_phone",
    ["label"] = "Green Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "green_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["greenlight_phone"] = {
    ["name"] = "greenlight_phone",
    ["label"] = "Green Light Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "greenlight_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["pink_phone"] = {
    ["name"] = "pink_phone",
    ["label"] = "Pink Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "pink_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["white_phone"] = {
    ["name"] = "white_phone",
    ["label"] = "White Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "white_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["wet_classic_phone"] = {
    ["name"] = "wet_classic_phone",
    ["label"] = "Wet Classic Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_classic_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_black_phone"] = {
    ["name"] = "wet_black_phone",
    ["label"] = "Wet Black Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_black_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_blue_phone"] = {
    ["name"] = "wet_blue_phone",
    ["label"] = "Wet Blue Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_blue_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_gold_phone"] = {
    ["name"] = "wet_gold_phone",
    ["label"] = "Wet Gold Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_gold_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_purple_phone"] = {
    ["name"] = "wet_purple_phone",
    ["label"] = "Wet Purple Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_purple_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_red_phone"] = {
    ["name"] = "wet_red_phone",
    ["label"] = "Wet Red Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_red_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "Did you really think that swimming in the ocean with your phone was a good idea?"
},

["wet_green_phone"] = {
    ["name"] = "wet_green_phone",
    ["label"] = "Wet Green Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_green_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["wet_greenlight_phone"] = {
    ["name"] = "wet_greenlight_phone",
    ["label"] = "Wet Green Light Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_greenlight_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["wet_pink_phone"] = {
    ["name"] = "wet_pink_phone",
    ["label"] = "Wet Pink Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_pink_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["wet_white_phone"] = {
    ["name"] = "wet_white_phone",
    ["label"] = "Wet White Phone",
    ["weight"] = 700,
    ["type"] = "item",
    ["image"] = "wet_white_phone.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "They say that Quasar Smartphone is the same as an iPhone, what do you think?"
},

["phone_hack"] = {
    ["name"] = "phone_hack",
    ["label"] = "Phone Hack",
    ["weight"] = 300,
    ["type"] = "item",
    ["image"] = "phone_hack.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "With this chip, you can access hidden areas of Discord."
},

["phone_module"] = {
    ["name"] = "phone_module",
    ["label"] = "Phone Module",
    ["weight"] = 300,
    ["type"] = "item",
    ["image"] = "phone_module.png",
    ["unique"] = true,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = "It seems that we can fix a wet phone with this module, interesting."
},