INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('classic_phone', 'Classic Phone', 10),
	('black_phone', 'Black Phone', 10),
    ('blue_phone', 'Blue Phone', 10),
    ('gold_phone', 'Gold Phone', 10),
    ('purple_phone', 'Purple Phone', 10),
    ('red_phone', 'Red Phone', 10),
    ('green_phone', 'Green Phone', 10),
    ('greenlight_phone', 'Green Light Phone', 10),
    ('pink_phone', 'Pink Phone', 10),
    ('white_phone', 'White Phone', 10),

    ('wet_classic_phone', 'Wet Classic Phone', 10),
	('wet_black_phone', 'Wet Black Phone', 10),
    ('wet_blue_phone', 'Wet Blue Phone', 10),
    ('wet_gold_phone', 'Wet Gold Phone', 10),
    ('wet_purple_phone', 'Wet Purple Phone', 10),
    ('wet_red_phone', 'Wet Red Phone', 10),
    ('wet_green_phone', 'Wet Green Phone', 10),
    ('wet_greenlight_phone', 'Wet Green Light Phone', 10),
    ('wet_pink_phone', 'Wet Pink Phone', 10),
    ('wet_white_phone', 'Wet White Phone', 10),

    ('phone_hack', 'Phone Hack', 10),
    ('phone_module', 'Phone Module', 10)
;