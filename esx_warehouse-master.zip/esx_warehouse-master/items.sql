INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('warehouse_key', 'Warehouse Key', 1),
	('access_key', 'Access Key', 1)
;