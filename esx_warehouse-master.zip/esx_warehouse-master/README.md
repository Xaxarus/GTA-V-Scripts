# esx_warehouse
Detailed smuggling job inspired by GTA: Online by utku

Buying: https://streamable.com/o1qxb
Selling: https://streamable.com/ziz0f

Sharing (even if you edit it slightly or heavily) without my permission is strictly prohibited at this point.


My Patreon for more of everything: https://www.patreon.com/utkforeva

I have looked at some other scripts to write SQL side of the resource. And of course, many other resources to figure out some natives that are not well documented, if you see or feel anything you write is used here tell me, please.


Code needs a lot of organization and fixing, there are a lot of useless methods right now. If you have something in your mind just request-pull. Thx for using and contributing to this resource.


It registers to user steam identifier individually, so this means more than one player can use this simultaneously but in the warehouse which is not realistic and not cool. So if you are adding this to a RP server I highly recommend only make this job available for one person at this point. When I have time I will be making this warehouse based or job-based rather than player based.


DO NOT FORGET TO ADD "warehouse_key" AND "access_key" TO YOUR ITEMS IN DATABASE!


Using of issues are appreciated.


Required resources:

ESX: https://github.com/ESX-Org/es_extended

mythicnotify: https://github.com/mythicrp/mythic_notify

progressBars: https://github.com/torpidity/progressBars/tree/1.0

you also need to enable load ipls, bob74_ipl is enough
