---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Your idea**
Add any context or screenshots about the feature request here.
