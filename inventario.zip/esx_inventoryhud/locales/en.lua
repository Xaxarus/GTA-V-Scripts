Locales["en"] = {
	["cash"] = "Dinheiro",
	["black_money"] = "Black Money",
	["player_nearby"] = "Não está por perto!",
	["players_nearby"] = "Não ha nínguem por perto!",
	["openinv_help"] = "Opens inventory of another player",
	["openinv_id"] = "Player ID",
	["no_permissions"] = "Não tens premissoes para isso!",
	["no_player"] = "Jogador nao encontrado!",
	["player_inventory"] = "Inventario"
}
