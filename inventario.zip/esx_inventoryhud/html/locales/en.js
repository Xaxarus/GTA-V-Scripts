var invLocale = new Object();
invLocale.dropItem = "Largar";
invLocale.useItem = "Usar";
invLocale.giveItem = "Dar";
invLocale.secondInventoryNotAvailable = "";