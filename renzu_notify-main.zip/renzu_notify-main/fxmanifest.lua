fx_version 'cerulean'
-- Renzu Notify
-- MADE BY Renzuzu
game 'gta5'

lua54 'on'
-- is_cfxv2 'yes'
-- use_fxv2_oal 'true'

ui_page {
    'html/index.html',
}

client_scripts {
	'config.lua',
	"client.lua"
}

files {
	'html/index.html',
	'html/*.js',
	'html/css/*.css',
}